var A = 2
while (A<=20){
	var B = 1
	println("Multiplication table of: " + A)
	while (B<=20){
		println(s"$A x $B = " + A*B)
		B = B+1
	}
	A = A+1
}                                                                      