


//Create Features Of Interest
var randInt = scala.util.Random
/*def createArray(n:Int): Array[Int] = Array.fill(n){randInt.nextInt(n)} //Even is North, Odd is East, Objects in pairs
var FOI: Array[Int] = createArray(10)
for (i <- 0 to FOI.length - 1){
	if (randInt.nextInt(2) == 1){
		FOI(i) = FOI(i) * -1

	}
	print(" "+ FOI(i))
}*/
def makeRandInt(): Int={
	var number = randInt.nextInt(1)
	if randInt.nextInt(2) > 0){
		number = number * -1
	}
	return number
}


var FOI = Array(0,0,0,0,0,0,0,0,0,0)
for(i <- 0 to FOI.length-1){
	FOI(i) = makeRandInt()
	}
	
	println(FOI(i))
}

//Make places unique
for (outside<-0 to FOI.length-1){ //What we're checking
	for(inside<- 0 to FOI.length-1){//Rest of array
		if (outside != inside){//Not checking against itself
			if (FOI(outside)%2 == 0){ //Even
				if(FOI(inside)%2 == 0){//Only checks Norths (Evens)
					while(FOI(outside) == FOI(inside)){//while its the same number
						FOI(inside) = makeRandInt()
						//FOI(inside) = randInt.nextInt(10)
					}
				}
			}
			else{//Checking Easts (Odds)
				if(FOI(inside)%2 != 0){
					while(FOI(outside) == FOI(inside)){
						FOI(inside) = makeRandInt()
						//FOI(inside) = randInt.nextInt(10)
					}
				}
			}
		}		
	}
	println(s"number $outside: "+FOI(outside))
}


//game code
var pN = 0 //player North position, -ve = South
var pE = 0 //player East position, -ve = West
var end = true //keeps game running 
while (end){
	println("Choose a direction to go: N/S/W/E (North,South,West,East")
	var choice = readLine().toLowerCase
	choice match{
		case "n"|"north" => pN += 1
		case "s"|"south" => pN -= 1
		case "e"|"east"  => pE += 1
		case "w"|"west"  => pE -= 1
	}
	println(s"You are $pN metres North")
	println(s"You are $pE metres East")
	for (i <- 0 to FOI.length -1){
		if (i%2 == 0){
			if (pN == FOI(i) && pE == FOI(i+1)){
				println("You have encountered")
				end = false
			}
		}
		else{
			if (pE == FOI(i) && pN == FOI(i-1)){
				println("You have found!")
				end = false
			}
		}
		
	}
}
