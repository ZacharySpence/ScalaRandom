var countries = List("UK","USA","Pakistan")
var capitals = countries.map(findCapital)

def findCapital(c:String):String={
	var city = ""
	c match{
		case "UK" => city = "London"
		case "USA" => city = "New York"
		case "Pakistan" => city = "Islamabad"
	}
	return city
}

print(capitals) 