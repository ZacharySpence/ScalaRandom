class MyExp extends Exception{}
class AbsentiesException extends Exception{}



try{
	var first = 10
	var second = 12
	if (first < second){
		var ref = new MyExp()
		throw ref
	}
}
catch{
	case my:MyExp => println("Chicken wing")
}
class Accounts{
	def salaryCalculations(Salary:Int,Absenties:Int)={
		if(Absenties>=6){
			var x = new AbsentiesException()
			throw x
		}
	}
}

var ref = new Accounts()
try{
	ref.salaryCalculations(200,7)
}
catch{
	case x:AbsentiesException => println("You're fired!")
}