var numbers = Array(-9,-8,-6)
var i = 0
var Biggest = numbers(0)

while (i< numbers.length){
	if (Biggest < numbers(i)){
		Biggest = numbers(i)
	}
	i += 1
}
print(Biggest)