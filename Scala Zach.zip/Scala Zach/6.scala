class ONE {
	var A = 0
	def message()={
		println("Hello")
	}
}

class TWO extends ONE{
	def msg2()={
		println("Hello my friends")
	}
}
var ref = new TWO()