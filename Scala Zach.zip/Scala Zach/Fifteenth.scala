println("Choose a day")
var day = readLine().toLowerCase()
var end = true
while (end ){
	day match{
		case "monday" => println(1)
			end = false
		case "tuesday" => println(2)
			end = false
		case "wednesday" => println(3)
			end = false
		case "thursday" => println(4)
			end = false
		case "friday" => println(5)
			end = false
		case "saturday" => println(6)
			end = false
		case "sunday" => println(7)
			end = false
		case default => 
			println("Choose an actual day please")
			day = readLine().toLowerCase()
	}
}
println("Finished")
