class Boom(A:Int,B:Int){
	var x = 95
	println(A+","+B)
	def message()={
		var T = 14
		var x = 25
		println("T:" + T)
		println("X:" + this.x)
	}
	def message2()={
		println("X:"+ x)
	}
	def hello()={
		print(" Physics "+A)
		print(" Chemistry "+B)
	}
}
var x = new Boom(4,5)
x.message()
x.message2()
x.hello()