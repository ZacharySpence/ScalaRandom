import java.sql.{Connection,DriverManager}
try{
	Class.forName("com.mysql.jdbc.Driver")
	var connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Bank","root","")
	val statement = connection.createStatement

	def createAccount(pname:String)={
		println("You need to create an account")
			var name = pname
			println("Please put your address")
			var addr = readLine
			statement.executeUpdate(s"Insert Into Personal (name, address) VALUES('$name','$addr')")
	}

	println("Who is using this? please type your name")
	var personName = readLine.toLowerCase
	var query=(s"Select count(*) as CC FROM Personal WHERE Name = '$personName'")
	var query2 = (s"SELECT Accno FROM Personal WHERE Name = '$personName'")
	var personAccno = statement.executeQuery(query)
	personAccno.next()
	if (personAccno.getInt("CC") == 0){
		createAccount(personName)
	}
	personAccno = statement.executeQuery(query2)
	personAccno.next()
	var accNo = personAccno.getInt("Accno")

	var end = true
	while (end){
		println("Please choose 1 of 3 options: 1.Create Account, 2.Deposit Money, 3.Withdraw Money, 4.Finish")
		var choice = readInt
		choice match {
			case 1 => createAccount(personName)

			case 2 => println("How much are you depositing")
				var deposit = readInt
				statement.executeUpdate(s"INSERT INTO Deposit (Accno,Amount) VALUES ('$accNo' , '$deposit')")
				personAccno = statement.executeQuery(query2)
				personAccno.next()

			case 3 => println("How much are you withdrawing")
				var withdraw = readInt
				statement.executeUpdate(s"INSERT INTO Withdraw(Accno, Amount) VALUES ('$accNo', '$withdraw')")

			case 4 => end = false
				println("Goodbye")

			case _ => println("That isn't a valid option")
		}
	}
}
catch{
	case e:Exception => println(e)
}
