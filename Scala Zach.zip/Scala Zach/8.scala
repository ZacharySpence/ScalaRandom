abstract class Bank{
	def deposit(a:Int)
	def withdraw(a:Int)
	def showBalance()
	def msg()={
		println("Hello")
	}
}

class HSBC extends Bank{
	override def deposit(A:Int)={
		print(A + "deposited")
	}
	override def withdraw(A:Int)={
		println(A + "withdrawn")
	}
	override def showBalance()={
		print("balance")
	}
}
var ref = new HSBC()
ref.showBalance()