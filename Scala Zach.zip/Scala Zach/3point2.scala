var num = 1
var I = 0
def convertNumbertoString(number:Int): String ={
	var convertedString = " "
	var hundreds = (number%1000)
	var tens =  (number%100)
	var singles = (number%10) 
	//var numberstring  = ((number.toString()).length).toInt
	//var numberstrings = number.toString
	//var numberstring  = ((number.toString()).length).toInt
	//var numberstrings = number.toString
	//for (I <- 0 to (numberstring -1)){
		//println((numberstring-I) +" heeeyo")
		//if (I < (numberstring -1)){
			//println(convertedString + " ITS HERE")
			//println(numberstrings(0) + " Number StRING")
			//numberstrings = numberstrings.substring(I)
		//}
		//println(convertedString + " ITS HERE")
		//println((numberstrings(0).toString) + " Number StRING")
		//numberstrings = numberstrings.substring(I)
		//println("Number"+ (numberstring - I))
		//println (number)

		//(numberstring - I) match{
			
			((number/1000).toString) match{
				case "0" => convertedString
				case "1" => convertedString += " one-thousand"
				case "2" => convertedString += " two-thousand"
				case "3" => convertedString += " three-thousand"
				case "4" => convertedString += " four-thousand"
				case "5" => convertedString += " five-thousand"
				case "6" => convertedString += " six-thousand"
				case "7" => convertedString += " seven-thousand"
				case "8" => convertedString += " eight-thousand"
				case "9" => convertedString += " nine-thousand"
			}
			((hundreds/100).toString) match{
				case "0" => if (convertedString.substring(convertedString.length-3) == "and"){
						convertedString
					} 
					else{
						convertedString += " and"
					}
					
				case "1" => convertedString += " one-hundred"
				case "2" => convertedString += " two-hundred"
				case "3" => convertedString += " three-hundred"
				case "4" => convertedString += " four-hundred"
				case "5" => convertedString += " five-hundred"
				case "6" => convertedString += " six-hundred"
				case "7" => convertedString += " seven-hundred"
				case "8" => convertedString += " eight-hundred"
				case "9" => convertedString += " nine-hundred"
			}


			((tens/10).toString) match{
				case "0" => convertedString += " and"
				case "1" => (number%10) match{
					case 0 => convertedString += " ten"
					case 1 => convertedString += " eleven"
					case 2 => convertedString += " twelve"
					case 3 => convertedString += " thirteen"
					case 4 => convertedString += " fourteen"
					case 5 => convertedString += " fifteen"
					case 6 => convertedString += " sixteen"
					case 7 => convertedString += " seventeen"
					case 8 => convertedString += " eighteen"
					case 9 => convertedString += " nineteen"
				}
					 return convertedString
				case "2" => convertedString += " twenty"
				case "3" => convertedString += " thirty"
				case "4" => convertedString += " fourty"
				case "5" => convertedString += " fifty"
				case "6" => convertedString += " sixty"
				case "7" => convertedString += " seventy"
				case "8" => convertedString += " eighty"
				case "9" => convertedString += " ninety"

			}
			
			singles match{
				case 0 => return convertedString 
				case 1 => convertedString += " one"
				case 2 => convertedString += " two"
				case 3 => convertedString += " three"
				case 4 => convertedString += " four"
				case 5 => convertedString += " five"
				case 6 => convertedString += " six"
				case 7 => convertedString += " seven"
				case 8 => convertedString += " eight"
				case 9 => convertedString += " nine"
			}
	return convertedString
}
print(num +" = "+ convertNumbertoString(num))

var k = 1
for (k <- 1 to 95){
	println(convertNumbertoString(k))
}