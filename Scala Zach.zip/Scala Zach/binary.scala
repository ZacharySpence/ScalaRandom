def makeBinary(number:Int): String={
	println("Please give a number")
	var num = number
	var binary = ""
	var binaryRead = ""
	println("Starting number: " + num)
	while (num > 0){
		if (num%2 == 0){
			binary = binary + "0"
			binaryRead = "0" + binaryRead
		}
		else{
			binary = binary + "1"
			binaryRead = "1" + binaryRead
		}
		num = num/2
	}
	println("Binary Code: " + binaryRead)
	return binary
}



def makeDecimal(binary:String): Int={
	var number = 0
	var A = 0
	var Power = 0
	var Tempnum = 1
	var K = binary.length
	while (K > 0){
		if (binary.substring(A,A+1) == "1"){
			Power = A
			Tempnum = 1
			for (i <- 1 to A){
				if (A > 0){
					Tempnum = Tempnum * 2
				}
			}
			number+= Tempnum
		}
		A += 1
		K -= 1
	}
	print("Your number was: " +number)
	return number
}
makeDecimal(makeBinary(8))