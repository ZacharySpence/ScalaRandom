import scala.swing._
class UI extends MainFraim{
	var title = "Gui program 1"
	var preferredSize = new Dimension(320,400)
	var contents = new Label("Here are the contents")
}

object guiProgramOne{
	def main(args:Array[String]){
		val ui = new UI
		ui.visible = true
		println("end of main function")
	}
}

//fsc gui1.scala
//scala guiProgramOne