abstract class Animal{
	def bleat
}

trait Cuddly {
	def cuddle
	def kiss
	def lick
}

trait fourLeggedAnimal {
	def walk
	def run
}

class Deer extends Animal with Cuddly{
	override def bleat()={
		println("Bark")
	}
	override def cuddle()={
		println("she nuzzles your hand")
	}
	override def kiss()={
		println("She gives you a wet boop with her nose")
	}
	override def lick()={
		println("she licks your hand")
	}

}

var Puppy = new Dog()
Puppy.speak()
Puppy.startTail()
Puppy.walk()
