println("What were your marks for physics?")
var physics = readInt()
println("What were your marks for chemistry?")
var chem = readInt()
println("What were your marks for maths?")
var maths = readInt()
var total = physics + chem + maths
var percentage = total *100/300
if (percentage>=60){
	println(s"Total Marks: $total" + "\n" + s"Percentage: $percentage")
}
else{
	println("You have failed the Year")
}