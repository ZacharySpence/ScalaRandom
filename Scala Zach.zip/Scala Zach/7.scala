class Math {
	var a = 10
	def Addition(A:Int,B:Int)={
		var Result = A+B
		print("Result:" + Result)
	}
	def Subtraction(A:Int,B:Int)={
		print(A-B)
	}
}
class Math2 extends Math{
	def multiplication(A:Int,B:Int)={
		var Result = A*B
		println("Result: " + Result)
	}
}

class Math3 extends Math2{
	override def Subtraction(A:Int,B:Int)={
		var Result = A-B
		println("Result: "+ Result)
	}
}

var math1 = new Math()
var math2 = new Math2()
var math3 = new Math3()
math1.Subtraction(4,2)
math2.Subtraction(4,2)
math2.multiplication(2,2)
math3.Subtraction(4,2)
