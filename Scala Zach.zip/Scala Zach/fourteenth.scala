var msg = "I like radish with radishes and soupy radish with boiled radish"

var find = "radish"
var I = 0
var number = 0
while (I < msg.length()-(find.length())){
	if (msg.substring(I,I+find.length()) == find && (msg.substring(I+find.length(),I+find.length()+1)) == " "){
		//println(msg.substring(I,I+find.length()))
		//println(msg.substring(I+find.length(),I+find.length()+1))
		number += 1
		I = I+find.length()-1
	}
	I += 1
	//println (I + " A")
}
if(msg.substring(I) == find){
	number += 1
}
print(number)