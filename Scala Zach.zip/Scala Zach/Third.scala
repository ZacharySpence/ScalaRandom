println("Type in a Salary")
var salary = readInt()
var tax = salary * 0.15
var netSalary = salary - tax
println (s"Tax is: $tax" +"\n" + "net Salary is: " + netSalary)
