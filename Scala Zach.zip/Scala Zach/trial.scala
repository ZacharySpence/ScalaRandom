var num = 1
var ("number" + num) = 3

print(number1)