var word = 1
var I = 0
var H = 0
var msg = "I Like Beans"

while (I < msg.length()){
	if (msg.substring(I, I+1) == " "){
		println()
	}
	else{
		print(msg.substring(I, I+1))
	}
	
	I += 1
}
