var num = 9999
var convertedString = " "
print (num)
def convertToString(number:Int): String ={
	var numba = number
	(numba/1000) match{
		case 0 => convertedString 
		case 1 => convertedString += " one"
		case 2 => convertedString += " two"
		case 3 => convertedString += " three"
		case 4 => convertedString += " four"
		case 5 => convertedString += " five"
		case 6 => convertedString += " six"
		case 7 => convertedString += " seven"
		case 8 => convertedString += " eight"
		case 9 => convertedString += " nine"
	}

	if ((numba/1000) > 0){
		convertedString += "-thousand"
	}

	numba = (numba%1000)

	(numba/100) match{
		case 0 => convertedString 
		case 1 => convertedString += " one"
		case 2 => convertedString += " two"
		case 3 => convertedString += " three"
		case 4 => convertedString += " four"
		case 5 => convertedString += " five"
		case 6 => convertedString += " six"
		case 7 => convertedString += " seven"
		case 8 => convertedString += " eight"
		case 9 => convertedString += " nine"
	}

	if ((numba/100) > 0){
		convertedString += "-hundred"
	}

	numba = (numba%100)

	(numba/10) match{
		case 0 => convertedString += " and"
		case 1 => (numba%10) match{
						case 1 => convertedString += " eleven"
						case 2 => convertedString += " twelve"
						case 3 => convertedString += " thirteen"
						case 4 => convertedString += " fourteen"
						case 5 => convertedString += " fifteen"
						case 6 => convertedString += " sixteen"
						case 7 => convertedString += " seventeen"
						case 8 => convertedString += " eighteen"
						case 9 => convertedString += " nineteen"
					}
		case 2 => convertedString += " twenty"
		case 3 => convertedString += " thirty"
		case 4 => convertedString += " fourty"
		case 5 => convertedString += " fifty"
		case 6 => convertedString += " sixty"
		case 7 => convertedString += " seventy"
		case 8 => convertedString += " eighty"
		case 9 => convertedString += " ninety"

	}

	numba = (numba%10)
	println(number + "numba!!")

	numba match{
		case 0 => convertedString 
		case 1 => convertedString += " one"
		case 2 => convertedString += " two"
		case 3 => convertedString += " three"
		case 4 => convertedString += " four"
		case 5 => convertedString += " five"
		case 6 => convertedString += " six"
		case 7 => convertedString += " seven"
		case 8 => convertedString += " eight"
		case 9 => convertedString += " nine"
	}
}
print(convertToString(num))