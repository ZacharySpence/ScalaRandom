def simpleArraySum(ar:Array[Int]): Int = {
	var A = 0
	for (a <- 0 to (ar.length-1)){
		A = A + ar[a]
		println(s"Result $a: " + A)
	}
	println("End Result" + A)
}