try{
	var A = 4
	var B = 0
	var C = A/B
	print("Result: "+ C)
}
catch{
	case a:ArithmeticException => {
		println("Whoopsy")
		
	}
}