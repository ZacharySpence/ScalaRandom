var regno = Array("B51515","bv2rrhr32h","fb23tb5","ggg335651","g45662")
var name = Array("Joshua", "Dijon mutard", "Zach", "Cheezisl"," Stan")
var marks = Array(12,66,82,58,46)


def addingToArrays(Len:Int)={
	var Regno = new Array[String](Len)
	var Name = new Array[String](Len)
	var Marks = new Array[Int](Len)
	for (k <- 0 to Len-1){
		println("Please put your registration number")
		Regno(k) = regno(k) //readLine
		println("Please put your name")
		Name(k) = name(k) //readLine
		println("Please give your marks")
		Marks(k) = marks(k) //readInt
		println("Thank you"+ "\n")
	}
	findMax(Marks,Name)
}




def findMax(Marks:Array[Int],Name:Array[String])={
	var first = Marks(0)
	var second = Marks(0)
	var fmark = 0
	var smark = 0
	for (m <- 0 to Marks.length-1){
		if (second > Marks(m)){
			second = Marks(m)
			smark = m
		}
	}
	var i = 0
	while (i < Marks.length){
		if (Marks(i) > second){
			if (Marks(i) > first){
				smark = fmark
				second =  first
				first = Marks(i)
				fmark = i


			}
			else{
				second = Marks(i)
				smark = i
			}
		}
		i += 1
	}
	println(first+ ","+ second)
	println(Name(fmark)+","+Name(smark))
}
addingToArrays(5)