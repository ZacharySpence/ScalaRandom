abstract class Draw{//Abstract because method inside is empty
	def Drawing()
}
class Line extends Draw{ //child class of Draw
	override def Drawing()={
		println("Draw Line")
	}
}
class Circle extends Draw{
	override def Drawing()={
		println("Draw Circle")
	}
}

def letsDoDrawing(x:Draw)={//the x:Draw references the address of the object of the class or its children (basically any class using this function
	//needs to either be the given class or extending (a child) of the given class)
	x.Drawing()
}

var l = new Line()
letsDoDrawing(l)
var c = new Circle()
letsDoDrawing(c)
