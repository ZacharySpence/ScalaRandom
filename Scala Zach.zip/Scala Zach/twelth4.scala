var msg = "I Like Beans"
var I = msg.length()
var H = msg.length()
var A = 0

while (I > 0){
	if (msg.substring(I-1, I) == " "){
		println()
	}
	else{
		print(msg.substring(A, A+1))
		A+=1
	}
	I -= 1
}