var physics = 70
var chemistry = 80
var maths = 90
var fail = 0
if (physics < 60){
	fail += 1
}
if (chemistry < 60){
	fail += 1
}
if (maths < 60){
	fail += 1
}
if (fail == 0){
	var total = physics + chemistry + maths
	var percentage = total *100/300
	println(s"Total marks: $total " + s", Overall Percentage: $percentage")
}
if (fail == 1){
	println("Retake exams")
}
if (fail == 2){
	println("Retake the Course")
}
if (fail == 3){
	println("Get Out")
}