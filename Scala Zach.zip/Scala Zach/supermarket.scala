var eggs = 1
var bacon = 3
var total = 0
println("How many eggs do you want?")
var amount = readInt()
total = eggs * amount
println("How much bacon do you want?")
amount = readInt()
total = total + (bacon *amount)

println(total + ", It costs that much")