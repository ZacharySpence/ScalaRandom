var total = 0
var end = true
var choices = ""
var n1 = 0
var n2 = 0 
var output = 0

def add(n1:Int, n2:Int): Int ={
	total = n1+n2
	return total
}

def delete(n1:Int,n2:Int): Int ={
	total = n1-n2
	return total
}

def multiply(n1:Int,n2:Int): Int ={
	total = n1*n2
	return total
}

def divide(n1:Int,n2:Int): Int ={
	total = n1/n2
	return total
}

while (end){
	if (n1 == 0){
		println("Choose a number")
		n1 = readInt()
	}
	
	println("Choose (1/2/3/4), 0 to Finish Calculations")
	var choice = readInt()

	if (choice != 0){
		println("Choose your second number")
		n2 = readInt()
	}
	choice match{
		case 0 =>
			end = false

		case 1 => 
			output = add(n1,n2)
			n1 = output
			println("Your Addition is: " + output)

		case 2 => 
			output = delete(n1,n2)
			n1 = output
			println("Your Subtraction is: " + output)

		case 3 => 
			output = multiply(n1,n2)
			n1 = output
			println("Your Multiplication is: " + output)

		case 4 => 
			output = divide(n1,n2)
			n1 = output
			println("Your Division is: " + output)
	}
}