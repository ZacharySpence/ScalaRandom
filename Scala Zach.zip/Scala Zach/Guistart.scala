import scala.swing._
import java.awt.Color

class UI extends MainFrame{ //Created the main User Interface Frame
  val la = new Label("Look at me!")

  la.foreground = Color.BLUE
  title = "GUI Programme 4"
  //preferredSize = new Dimension(400,320)
  contents = new BoxPanel(Orientation.Vertical){
    contents += la
    contents += Swing.VStrut(10)
    contents += Swing.Glue
    //
    contents += new Label("Hellooo")//Creates a Label
    contents += Swing.VStrut(10)//Struts -> pixel space 
    contents += Swing.Glue//sticks item to border
    //
    contents += Button("Change Text"){changeText()}
    contents += Swing.VStrut(5)
    //
    contents += Button("Press me moar"){pressMe()}//Button with {event handle}
    contents += Swing.VStrut(5)
    //
    contents += Button("Close"){closeMe()}
    
    //couldve done var box = new BoxPanel.....
      //box.contents += new Label...


    //border = Swing.EmptyBorder(10,10,10,10)//puts border around the components
    //border = Swing.BeveledBorder(Swing.Lowered)//or Raised
    //border = Swing.MatteBorder(10,10,10,10,java.awt.Color.GREEN)
    //border = Swing.TitledBorder(Swing.LineBorder(java.awt.Color.RED),"Fun")
    border = Swing.TitledBorder(Swing.EtchedBorder(Swing.Lowered),"Fun")
    //border = Swing.CompoundBorder(Swing.BeveledBorder(Swing.Lowered),Swing.EmptyBorder(10,10,10,10))
  }

  def pressMe(){
    Dialog.showMessage(contents.head,"Thank you!", title = "you pressed me") 
    //creates a new page with contents and a title
  }

  def changeText(){
    var r = Dialog.showInput(contents.head, "New label text", initial = la.text)
    //showInput will open a window asking for an input
    r match{
      case Some(s) => la.text = s
      case None =>
    }
  }

  def closeMe(){
    val res = Dialog.showConfirmation(contents.head,"Do you really want to quit?",optionType = Dialog.Options.YesNo,title=title)
    //Asks for confirmation
    if (res == Dialog.Result.Ok)
      sys.exit(0)
  }

 }

object GUIProgrammeOne{
  def main(args:Array[String]){
    val ui = new UI
    ui.visible = true
    println("End of main function")
  }
}

