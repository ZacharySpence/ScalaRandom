println("How hot is it in your country?")
	var temp = readInt()
if(temp > 40){
	println("warm")
}
else if (temp == 40){
	println("Juuuust right")
}
else{
	println("cold")
}