var word = 1
var I = 0
var H = 0
var msg = "I Like Beans"

while (I < msg.length()){
	if (msg.substring(I, I+1) == " "){
		println(msg.substring(H,I+1))
		H = I+1
		word += 1

	}
	I += 1
}

println(msg.substring(H))
println (word)

