import java.sql.{Connection,DriverManager}
try{
	Class.forName("com.mysql.jdbc.Driver")
	var connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Bank","root","")
	val statement = connection.createStatement


	class Bank{
		def createAccount()={
			println("Please create a username")
			var username = readLine
			println("What is your address")
			var address = readLine
			statement.executeUpdate(s"INSERT INTO Personal (Name, Address) VALUES('$username','$address')")


			var showNewAccountQuery = "SELECT * FROM Personal WHERE Accno = (SELECT Max(Accno) FROM Personal)"
			var showNewAccount = statement.executeQuery(showNewAccountQuery)
			showNewAccount.next()
			var showNewName = showNewAccount.getString("Name")
			var showNewAccno = showNewAccount.getInt("Accno")
			var showNewBalance = showNewAccount.getInt("Balance")
			println("Your new account details: ")
			println("--------------------------")
			println("Accno: "+showNewAccno)
			println("Username: "+showNewName)
			println("Balance: "+showNewBalance)
		}
		def withdraw(Accno:Int)={
			var selectAccountQuery = s"SELECT Balance FROM Personal WHERE accno = '$Accno'"
			var selectAccount = statement.executeQuery(selectAccountQuery)
			selectAccount.next()
			var showNewBalance = selectAccount.getInt("Balance")

			println("You have: "+showNewBalance+" Pounds")
			println("How much would you like to withdraw")
			var withdrawAmount = readInt
			while (withdrawAmount > showNewBalance){
				println("You do not have enough in your account. please withdraw less")
				withdrawAmount = readInt
			}
			statement.executeUpdate(s"INSERT INTO Withdraw (Accno, amount) VALUES('$Accno','$withdrawAmount')")
			statement.executeUpdate(s"UPDATE Personal SET Balance = Balance-'$withdrawAmount' WHERE accno = '$Accno'")
			var newNewBalance = showNewBalance - withdrawAmount
			println("You have withdrawn: "+withdrawAmount+" Pounds")
			println("You have: "+newNewBalance+" Pounds left in your account")
			println("\n")


		}
		def deposit(Accno:Int)={
			var selectAccountQuery = s"SELECT Balance FROM Personal WHERE accno = '$Accno'"
			var selectAccount = statement.executeQuery(selectAccountQuery)
			selectAccount.next()
			var showNewBalance = selectAccount.getInt("Balance")

			println("You have: "+showNewBalance+" Pounds")
			println("How much would you like to deposit?")
			var depositAmount = readInt
			while (depositAmount <= 0){
				println("You need to deposit more than 0")
				depositAmount = readInt
			}
			statement.executeUpdate(s"INSERT INTO Deposit (Accno, amount) VALUES('$Accno', '$depositAmount')")
			statement.executeUpdate(s"UPDATE Personal SET Balance = Balance + '$depositAmount' WHERE accno = '$Accno'")
			var newNewBalance = showNewBalance + depositAmount
			println("You have deposited: "+depositAmount+" Pounds")
			println("You have: "+newNewBalance+" Pounds left in your account")
			println("\n")
		}

	}


var HSBC = new Bank()
var NatWest = new Bank()
HSBC.createAccount()
println("Please put your account number in. If you have forgotten, you will have to call the bank. Sorry for any inconvenience")
var accountNumber = readInt

HSBC.deposit(accountNumber)
HSBC.withdraw(accountNumber)


}
catch{
	case e:Exception => println(e)
}