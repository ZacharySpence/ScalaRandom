//Global, important variables
//var Qdb = import.sql.QuestsDB

	var player = ""
	var CS:CharacterSheet = new CharacterSheet()
	var place = ""
	//

	//Connecting DB

	//

	//CLASSES

	//Character Sheet class
	class CharacterSheet{
		var Inventory = new Inventory()
		var Money = 0
		var QuestList = 0//(SELECT Name FROM QuestsDB WHERE Status = Acquired)
	}
	//



	//inventory class
	class Inventory{

		var inventory =  new Array[String](15)
		fill(15,inventory)
		private var Inumber = 0

		def checkInumber():Int={//checks the most empty inventory slot
			for (k <- 0 to inventory.length-1){
				if (inventory(k) == "empty"){
					return k
				}
			}
			return (inventory.length -1)
		}

		def Iadd(num:Int,what:String)={//adds into the inventory in the appropriate empty slot
			inventory(Inumber) = (s"$what x$num").toLowerCase
			Inumber = checkInumber()
		}

		def Iremove(num:Int,what:String)={//removes from the inventory from the appropriate slot
			Inumber = checkInumber()
			for (k <- 0 to inventory.length-1){
				if(findString(what,inventory(k))){
					inventory(k) = "empty"
				}
			}
		}
	}
	//certain String Index function

	//Need function to find index of certain bit of string _> For QUEST stuff, need to get 2nd index too
	def stringIndex(string:String,start:String): Int={
	 	for (k <- 0 to string.length-1){
	 		if (string.substring(k,k+1) == start){
	 			return k
	 		}
	 	}
	 	return string.length-1
	}

	//

	//Buy and Sell functions
	/*def Vendor(vendor:String)={
		var ItemStock = vendor match{
			case "Beena" => SQLBitems
			case "Fergo" => SQLFitems
			case "Marroon" => SQLMitems
			}
	}*/
	def Buy(Vendor:String)={ //Finds vendors stock and prints it
		//Vendor(Vendor)
	}

	def Sell(Vendor:String)={
		var actualLength = 0
		println("You have:")
		for (i <- 0 to CS.Inventory.inventory.length-1){
			if (CS.Inventory.inventory(i) != "empty"){
				println(CS.Inventory.inventory(i))
				actualLength +=1
			}
		}
		//var price = 0 //Select Name, Prices from ItemDB WHERE Name IN (player.charactersheet.inventory(All of It)) //Prints the price for each item in their inventory

		println("What would you like to sell")
		var sell = readLine()
		for (k <- 0 to actualLength-1){
			if (findString(sell,CS.Inventory.inventory(k))){
				var item = CS.Inventory.inventory(k)
				var quantity = CS.Inventory.inventory(k).substring(stringIndex(CS.Inventory.inventory(k),"x")+1)
				println(s"You have $quantity of them. How many do you want to sell?")
					var sold = readInt()
				CS.Money += 1 //((Select price FROM ItemDB where name = item)*sold)
			}
		}
		
	}

	//

	//Quest functions
	/*
	//Need to get Rewards string from QuestsDB...what?
	def QuestRewards(SQLQuestName:String,/*charactersheet:Object*/)={
		var rewardList = new Array[String](10)
		if (findString(")",/*SQLQuestName.Rewards*/)){
			for (k<-0 to /*SQLQuestName.Rewards.length*/){
				rewardList(k) = findReward(")",")")
			}
		}
		if (findString("@",/*SQLQuestName.Rewards*/)){
			//player.charactersheet.money += findReward(@,@)
			}
		if (findString("#",/*SQLQuestName.Rewards*/)){
			//player.charactersheet.Inventory.Iadd(findReward(#,#))
		}
	}

	def QuestUpdate(SQLQuestName:String)={ //Updates the Quest progress, minusing until it reaches 0 (completion)
		SQLQuestName.progress -= 1
		if (SQLQuestName.progress <= 0){
			QuestComplete(SQLQuestName)
		}
	}

	def QuestComplete(SQLQuestName:String)={
		QuestRewards(SQLQuestName)
		SQLQuestName.progress = SQLQuestName.tasks
	}
	*/
	//




	//
	//Choose who's playing
	def choosePlayer()={ 
		var pend = true
		while(pend){
			println("Who is playing?")
			player = readLine().toLowerCase()
			player match{
				case "chester" => player = "Chester" 
					CS = ChesterCS
				pend = false
				case "josh" => player = "Josh"
					CS = JoshCS
				pend = false
				case "chris" => player = "Chris"
				pend = false
				case "mac" => player = "Mac"
				pend = false
				case _ => println("Please use your real name, at least for now")
			}
		}
	}
	//

	//Finds string within Player's response -> for choices
	def findString(find:String,choice2:String): Boolean={
		var i = 0
		while (i < choice2.length){
			if (choice2.substring(i,i+1) == find.substring(0,1)){
				if (choice2.substring(i,i+find.length) == find){
					return true
				}	
			}
			i += 1
		}
		return false
	}
	/*def findString(find:String,choice2:String): Boolean={
		var i = 0
		while (i < (choice2.length-find.length)){
			if (choice2.substring(i,i+find.length) == find){
				return true
			}
			i += 1
		}
		return false
	}*/

	def street()={
		println("What would you like to do? Go to: (Beenas/Tavern/Outside/Smithy or stay where you are...in the street like a dolt")
		var choice1 = readLine().toLowerCase()
		(choice1.substring(0,1)) match {
			case "b" => place = "B"
			case "t" => place = "T"
			case "o" => place = "O"
			case "s" => place = "S"
			case _   => place = "Street"

		}
	}

	//Beena's Emporium encounter
	def Beenas()={
		println("Her door is open and you head inside to see a young woman in her early thirties mumbling to herself lost in thought")
		println("but before you can react her head whips towards you, a smile already encroached upon her face")
		println("'HELLLLLLLLOOOOO WELCOME TO BEEEENAS' she almost jumps onto you in excitement 'What can i do for you today")
		var choice2 = readLine().toLowerCase
		if(findString("buy",choice2)){
			println("'OH, what would you like to buy? I've got Beans of multiple varieties, healing salves, pelts and certain knicknacks just. for. you!'")
			//give player buy options
		}
		else if (findString("sell",choice2)){
			println("'I'd prefer you'd buy but my store could always use some stocking up, what have you got?")
			Sell("Beena")
			//check player's 'inventory' and offer prices for them
		}
		else if((findString("help",choice2)||findString("talk",choice2))||findString("quest",choice2)){
			println("'Well you know me, I always need some beans a picking")
			if (player == "Chester"){
				println ("*wink*")
			}
			//Add bean picking Quest to Active Quests
		}
		else{
			println("'Hello, anybody in there? yes, you, can you stop staring off into the abyss in my shop please'")
		}
	}
	//

	//Fergo's Smithy encounter
	def Smithy()={
		println("Walking across the small village you quickly end up at the Smithy who's forges are blazing in tune to the ringing of metal being hammered into shape")
		println("As you step around to the wide open entrance, you're greeting by the half-naked sight of a burly man in his late fifties, only a grand handlebar moustache gracing his otherwise bald body")
		println("Fergo does not notice you, do you want to grab his attention")
		var choice2 = readLine().toLowerCase()
		choice2.substring(0,1) match{
			case "n" => println("Alright, you stand there twiddling your thumbs")
			case "y" => println("Making some form of noise/movement, you get Fergo to stop hammering away for a moment, thus noticing your presence")
				println("'G'morn, what you want?'")
				var choice3 = readLine().toLowerCase()
				if (findString("buy",choice3)){
					println("'Looking to protect yerself or fuck something up?'")
					//give player buy options
				}
				else if (findString("sell",choice3)){
					println("'Well don't see what you could have to offer, but i'm never one to not have a peek first'")
					//check players inventory and offer prices for them
				}
				else if((findString("help",choice2)||findString("talk",choice2))||findString("quest",choice2)){
					println("'I'm always in need for some more Iron, same deal as before'")
					//Add MineField Quest to Active Quests
				}
				else{
					println("He stares at you hard for a moment while you daydream before going back to hammering away")
				}
		}
	}
	//

	//Marroon and Meyra's Tavern
	def Tavern()={
		println("The hot air wafts from the kitchen accompanied a cacaphony of noises which could only be taken as the murdering of a kitten")
		println("and you notice MARROON peering at you from behind the bard, rubbing what you swear is the same tankard as from three days ago with the same dishcloth")
		println("What would you like to do?")
		var choice2 = readLine().toLowerCase()

		if (findString("drink",choice2) || findString("eat",choice2)){
			println("MARROON, almost knowingly, produces a steaming plate of mashed meat and beans along with a tankard, placing it on the counter for you")
		}
		else if (findString("talk",choice2)){
			var c3end = true
			while (c3end){
				println("Who would you like to talk to, you can see Marroon and you suspect Meyra is in the kitchen")
				var choice3 =readLine().toLowerCase()
				choice3.substring(0,2) match{
					case "ma" => println("MARROON says hi with a slow nod") 
					c3end = false
					case "me" => println("You brave the kitchens to find MEYRA")
					 c3end = false
					case _ => println("I have no idea who you're talking to, but thin air is not the best social companion")
				}
			}	
		}
		else if (findString("upstairs",choice2)){
			println("You head upstairs")
		}
		else if (findString("downstairs",choice2)|| findString("cellar",choice2)){
			println("You head into the cellar")
		}
		else{
			println(s"you $choice2...great")
		}
	}
	//

	//Outside Encounter
	def Outside()={
		println("You head outside Pueblo and the forest quickly surrounds you, where are you headed?")
		//print quests
	}
	//


	//random functions

	//Fills inventory with empty slots
	def fill(num:Int,array:Array[String]){
		for (k <- 0 to array.length-1){
			array(k) = "empty"
		}

	}

	//

	//Making Characters
	var ChesterCS = new CharacterSheet()
	ChesterCS.Inventory.Iadd(3,"Wolf Pelts")
	ChesterCS.Inventory.Iadd(2,"Beans")
	ChesterCS.Inventory.Iadd(4,"Spears")
	println(ChesterCS.Inventory.inventory.length)
	var JoshCS = new CharacterSheet()
	//

	//inventory class


	//println(ChesterCS.inventory.inventory+ "inventory")

	//Main code bit
	choosePlayer()
	street()
	place match{
		case "T" => Tavern()
		case "B" => Beenas()
		case "S" => Smithy()
		case "O" => Outside()
		case _ => println("Hello")
	}
