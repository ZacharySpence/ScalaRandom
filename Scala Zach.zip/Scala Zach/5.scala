class Manchester{
	var Quantity = 100
	var Price = 2
}
var x = new Manchester()
print(x.Quantity)
print(x.Price)
x.Quantity = 50
println(x.Quantity)


class Results{
	var phy = 0
	var che = 0
	var mat = 0
	def showResults()={
		var total = phy+che+mat
		var per = total*150/450
		println(total)
		println(per)
	}
}
var peter = new Results()
peter.phy = 79
peter.che = 50
peter.mat = 90
peter.showResults()

class ASDA{
	var quantity = 0
	var price = 0
	var productName = ""

	def amount(): Int={
		var amount = quantity * price
		return amount
	}

	def bill()={
		var total = amount()
		var tax = (total * 15)/100
		var netProfit = total - tax
		println("Total:" + total + ", Tax:"+ tax+ ", Net Profit:"+ netProfit)
	}
}
var Asda1 = new ASDA()
Asda1.quantity = 30
Asda1.price = 5
Asda1.productName = "Beans"
Asda1.bill()


class Results2{
	private var phy = -1
	private var che = -1
	private var mat = -1
	private var total = 0

	def physics(A:Int): Boolean={
		if(A>=0 && A<= 150){
			phy = A
			return true
		}
		else{
			println("Invalid Marks")
			return false
		}
	}

	def maths(A:Int): Boolean={
		if(A>=0 && A<= 150){
			mat = A
			return true
		}
		else{
			println("Invalid Marks")
			return false
		}
	}

	def chemistry(A:Int): Boolean={
		if(A>=0 && A<= 150){
			che = A
			return true
		}
		else{
			println("Invalid Marks")
			return false
		}
	}

	private def calculations()={
			total = phy + che
	}

	private def grade(mark:Int): String={
		if (mark >= 90){
			return "got an A*"
		}
		if (mark >= 80){
			return "got an A"
		}
		if (mark >= 70){
			return "got a B"
		}
		if (mark < 70 && mark >= 50){
			return "got a C"
		}
		else{
			return (s"have Failed")
		}
	}

	def showResults()={
		if ((chemistry(che) && physics(phy)) && maths(mat)){
			calculations()
			println("Total marks: "+ total)
			println("For Chemistry you "+ grade(che))
			println("For Physics you "+ grade(phy))
			println("For Maths you "+ grade(mat))
			if (che < 50 || phy< 50 || mat < 50){
				println ("You have to repeat an exam")
			}
			else if((che< 50 && phy < 50)|| (che< 50 && mat < 50) || (phy < 50 & mat < 50)){
				println("You have to retale the course")
			}
			else if ((che < 50 && phy < 50)&& mat < 50){
				println("Get Out")
			}

		}
		else{
				println("One or more of you marks are invalid and so we cannot give you a total!")
		}
		
	}
}
var bilal = new Results2()

bilal.physics(53)
bilal.chemistry(72)
bilal.maths(42)
bilal.showResults()