var msg = "I Like Beans"
var A = 0
var B = 0
while (A < msg.length()){
	if (msg.substring(A,A+1) == " "){
		println(msg.substring(B,A+1))
		B = A+1

	}
	A += 1
}
println(msg.substring(B,A))
