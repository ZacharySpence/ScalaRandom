var A = 1
while (A<= 10){
	println("hello")
	A = A+1
}

while (A<=100){
	print(A)
	if(A%2==0){
		println("Even")
	}
	else{
		println("Odd")
	}
	A=A+1
}