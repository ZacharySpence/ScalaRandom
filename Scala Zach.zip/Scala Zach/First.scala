var A= 10
var B= 20
var C = A+B
println(C)