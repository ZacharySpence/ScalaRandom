var A = 1
while(A<=100){
	if (A != 5){
		print(A)
		if (A>5){
			print(" X ")
			if (A%2 == 0){
				print(" Even")
			}
			else{
				print(" Odd")
			}
		}
		else{
			print(" Y ")
		}
	}
	else{
		print(" Oops ")
	}
	A = A+1
}  