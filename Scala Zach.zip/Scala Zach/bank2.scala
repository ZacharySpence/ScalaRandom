class Bank{
	var A = 0
	def amount(x:Int)={
		println("Amount: "+(x*Bank.dollar))
	}
	def setDollar(x:Int)={
		Bank.dollar = x
	}
}

object Bank{
	var dollar = 90
}

var HSBC = new Bank()
var Natwest = new Bank()
var Barclays = new Bank()

HSBC.amount(4)
Natwest.amount(2)
Barclays.setDollar(300)