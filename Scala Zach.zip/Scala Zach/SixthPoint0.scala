var subjects = Array("Chemistry", "Maths", "Physics")
var subjectArray = new Array[Int](3)
var fail = true
var failNumber = 0
var failedArray = Array(1,1,1)
var end = true
var  GradePaperArray = Array("","","")

def takeExam(){
	for (i<-0 to 2){
	 	if (failedArray(i) == 1){
	 		println("What was your " + subjects(i) + " marks?")
			subjectArray(i) = readInt()
	 	}

	}
}

//println("Array: " + subjectArray.deep.mkString(","))

def checkFail(): Boolean={
	for (i<-0 to (subjectArray.length-1)){
		println(subjectArray(i))
		if (subjectArray(i) < 60){
			fail = false
			failedArray(i) = 1
			GradePaperArray(i)= "Retake " + subjects(i)
			failNumber += 1

		}
		else{
			failedArray(i) = 0
		}
	}
	if (failNumber == 2){
		println("Repeat the Course")
	}
	else if (failNumber == 3){
		println("Get Out")
		end = false
	}
	if (failNumber != 3){println(GradePaperArray.deep.mkString("\n"))}
	return fail
	
}

takeExam()
checkFail()
while (end){

	if (checkFail()== true){

		for (i<-0 to (subjectArray.length-1)){
			if (subjectArray(i) >= 90){
				println(subjects(i)+ " Grade: A*")
			}
			else if (subjectArray(i) >= 80){
				println(subjects(i)+ " Grade: A")
			}
			else if (subjectArray(i) >= 70){
				println(subjects(i)+ " Grade: B")
			}
			else if (subjectArray(i) >= 60){
				println(subjects(i)+ " Grade: C")
			}
			else{
				println("You have failed " + subjects(i))
			}
		}
		end = false
	}
	else{
		takeExam()
	 	fail = true
	 	failNumber = 0
	}
}


