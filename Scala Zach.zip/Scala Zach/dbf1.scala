import java.sql.{Connection,DriverManager}
try{
	Class.forName("com.mysql.jdbc.Driver")
	var connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/textbasedadventure","root","")
	val statement = connection.createStatement
	val rs = statement.executeQuery("select * from Itemdb")

	while (rs.next()){
		var name = rs.getString("Name")
		var price = rs.getInt("Price")
		println(name+"....."+price)
	}
}
catch{
	case e:Exception => println(e)
}