var chemistry = 92 
var physics = 75 
var maths = 42 
var total = chemistry + physics + maths 
var percentage = total*100/450 
println("Total is: "+ total)
println("Percentage is:") println(percentage+ "%")
