class Boom{
	println("Hello")
	def this(A:Int,B:Int,C:Int)={
		this()
		println("2nd constructor")
	}
	def this(A:Int,B:Int)={
		this()
		println("Third constructor")
	}
}


var bomber = new Boom(4,6)

class getSet(){
	private var _stuff = 3
	private var _name = "Jonnnnnn"

	def name_= (str:String)={
		_name = str
	}

	def name = _name
	

	//setter
	def stuff_= (x:Int)={
		_stuff = x
	}
	//getter
	def stuff = _stuff //its literally Stuff = stuff_ function
}

var hello = new getSet()
hello.stuff = 14 //getter = setter parameter
println(hello.stuff)
hello.name = "Whaat"
println(hello.name)