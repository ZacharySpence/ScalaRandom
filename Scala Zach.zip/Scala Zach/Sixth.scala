var physics = 80
var maths = 72
var chemistry = 66
var total = physics + chemistry + maths
var percentage = total *100/300
println(s"Total marks: $total" + "\n" + s"Percentage: $percentage")

if (percentage >= 90){
	println("A*")
}
else if (percentage >= 80){
	println("A")
}
else if (percentage >= 70){
	println("B")
}
else if (percentage >= 60){
	println("C)")
}
else{
	println("You have failed the year")
}





/*
var subjects = [Chemistry, Maths, Physics]
var subjectArray = newArray[Int](3)
For (i<-0 to 2){
	println(s"Put your $subjects marks")
	subjectArray[i] = readInt()
	println(subjectArray)
}*/