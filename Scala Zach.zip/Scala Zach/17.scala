var list1 = List(13,44,52,67,89)
var x = list1.filter(checkEven)

def checkEven(A:Int):Boolean={
	if (A%2 == 0){
		return true
	}
	else{
		return false
	}
}

print(x)