var msg = "I Like Beans"
var H = msg.length()
var I = msg.length()

while (I > 0){
	if (msg.substring(I-1, I) == " "){
		println(msg.substring(I,H))
		H = I-1

	}
	I -= 1
}
println(msg.substring(I,I+1))