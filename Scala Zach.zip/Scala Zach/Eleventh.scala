var A = 1
while (A <= 10){
	if (A%2 == 0){
		var B = 1
		while (B <= A){
			print(B)
			B = B+1
		}
	}
	else{
		println("\n" + A)
	} 
	A = A+1
}