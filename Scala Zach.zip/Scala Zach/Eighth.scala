println("How much did what you buy cost?")
var bill = readInt()
println("How much are you giving me?")
var payment  = readInt()
var balance = payment - bill
var fiftys = 0
var twentys = 0
var tens = 0
var fives = 0
var twos = 0
var ones  = 0
var remainder  = 0
//Details of payment
if (balance >= 50){
	fiftys = balance/50
	balance = balance - (fiftys*50)
}
if (balance >= 20){
 	twentys =balance)/20
	balance = balance - (twentys*20)
}
if (balance >=10){
	tens = balance/10
	balance = balance - (tens*10)
}
if (balance >=5){
	fives = balance/5
	balance = balance - (fives*5)
}
if (balance >=2){
	twos = balance/2
	balance = balance - (twos*2)
}
ones = balance

println("You need to give back: " + fiftys + " Fiftys, " + twentys + " Twentys, " + tens + " Tens, " + fives + " Fives, " + twos + " Twos, " + ones + " Ones")