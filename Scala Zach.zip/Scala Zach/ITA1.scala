var Players = Array("Chester","Josh")
var activePlayer = 0
var place = ""
def street()={
	println("What would you like to do? Go to: (Beenas/Tavern/Outside/Smithy or stay where you are...in the street like a dolt")
	var choice1 = readLine().toLowerCase()
	(choice1.substring(0,1)) match {
		case "b" => place = "B"
		case "t" => place = "T"
		case "o" => place = "O"
		case "s" => place = "S"
		case _   => place = "Street"

	}
}
def findString(find:String,choice2:String): Boolean={
	var i = 0
	while (i < choice2.length){
		if (choice2.substring(i,i+1) == find.substring(0,1)){
			if (choice2.substring(i,i+find.length) == find){
				return true
			}	
		}
		i += 1
	}
	return false
}

def Beenas()={
	println("Her door is open and you head inside to see a young woman in her early thirties mumbling to herself lost in thought")
	println("but before you can react her head whips towards you, a smile already encroached upon her face")
	println("'HELLLLLLLLOOOOO WELCOME TO BEEEENAS' she almost jumps onto you in excitement 'What can i do for you today")
	var choice2 = readLine().toLowerCase
	if(findString("buy",choice2)){
		println("'OH, what would you like to buy? I've got Beans of multiple varieties, healing salves, pelts and certain knicknacks just. for. you!'")
		//give player buy options
	}
	else if (findString("sell",choice2)){
		println("'I'd prefer you'd buy but my store could always use some stocking up, what have you got?")
		//check player's 'inventory' and offer prices for them
	}
	else if((findString("help",choice2)||findString("talk",choice2))||findString("quest",choice2)){
		println("'Well you know me, I always need some beans a picking")
		if (Players(activePlayer) == "Chester"){
			println ("*wink*")
		}
		//Add bean picking Quest to Active Quests
	}
	else{
		println("'Hello, anybody in there? yes, you, can you stop staring off into the abyss in my shop please'")
	}
}
def Smithy()={
	println("Walking across the small village you quickly end up at the Smithy who's forges are blazing in tune to the ringing of metal being hammered into shape")
	println("As you step around to the wide open entrance, you're greeting by the half-naked sight of a burly man in his late fifties, only a grand handlebar moustache gracing his otherwise bald body")
	println("Fergo does not notice you, do you want to grab his attention")
	var choice2 = readLine().toLowerCase()
	choice2.substring(0,1) match{
		case "n" => println("Alright, you stand there twiddling your thumbs")
		case "y" => println("Making some form of noise/movement, you get Fergo to stop hammering away for a moment, thus noticing your presence")
			println("'G'morn, what you want?'")
			var choice3 = readLine().toLowerCase()
			if (findString("buy",choice3)){
				println("'Looking to protect yerself or fuck something up?'")
				//give player buy options
			}
			else if (findString("sell",choice3)){
				println("'Well don't see what you could have to offer, but i'm never one to not have a peek first'")
				//check players inventory and offer prices for them
			}
			else if((findString("help",choice2)||findString("talk",choice2))||findString("quest",choice2)){
				println("'I'm always in need for some more Iron, same deal as before'")
				//Add MineField Quest to Active Quests
			}
			else{
				println("He stares at you hard for a moment while you daydream before going back to hammering away")
			}
	}
}

def Tavern()={
	println("The hot air wafts from the kitchen accompanied a cacaphony of noises which could only be taken as the murdering of a kitten")
	println("and you notice MARROON peering at you from behind the bard, rubbing what you swear is the same tankard as from three days ago with the same dishcloth")
	println("What would you like to do?")
	var choice2 = readLine().toLowerCase()

	if (findString("drink",choice2) || findString("eat",choice2)){
		println("MARROON, almost knowingly, produces a steaming plate of mashed meat and beans along with a tankard, placing it on the counter for you")
	}
	else if (findString("talk",choice2)){
		var c3end = true
		while (c3end){
			println("Who would you like to talk to, you can see Marroon and you suspect Meyra is in the kitchen")
			var choice3 =readLine().toLowerCase()
			choice3.substring(0,2) match{
				case "ma" => println("MARROON says hi with a slow nod") 
				c3end = false
				case "me" => println("You brave the kitchens to find MEYRA")
				 c3end = false
				case _ => println("I have no idea who you're talking to, but thin air is not the best social companion")
			}
		}	
	}
	else if (findString("upstairs",choice2)){
		println("You head upstairs")
	}
	else if (findString("downstairs",choice2)|| findString("cellar",choice2)){
		println("You head into the cellar")
	}
	else{
		println(s"you $choice2...great")
	}
}

def Outside()={
	println("You head outside Pueblo and the forest quickly surrounds you, where are you headed?")
	//print quests
}


/*while (I < msg.length()-(find.length())){
	if (msg.substring(I,I+find.length()) == find && (msg.substring(I+find.length(),I+find.length()+1)) == " "){
		//println(msg.substring(I,I+find.length()))
		//println(msg.substring(I+find.length(),I+find.length()+1))
		number += 1
		I = I+find.length()-1
	}
	I += 1
	//println (I + " A")
}
if(msg.substring(I) == find){
	number += 1
}
print(number)
*/

//Main code bit
street()
place match{
	case "T" => Tavern()
	case "B" => Beenas()
	case "S" => Smithy()
	case "O" => print("o")
	case _ => println("Hello")
}