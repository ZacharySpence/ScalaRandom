def operations(Calculate:(Int,Int)=>Unit)={
	println("Choose a number")
	var A = readInt
	println("Choose a second number")
	var B= readInt
	Calculate(A,B)
}

def Add(A:Int,B:Int)={
	var result = A+B
	println("Result: " + result)
}

def Subtract(A:Int,B:Int)={
	var result = A-B
	println("Result: " + result)
}

def Division(A:Int,B:Int)={
	var result = A/B
	println("Result: " + result)
}

def Multiplication(A:Int,B:Int)={
	var result = A*B
	println("Result: " + result)
}


var end = 0
while (end == 0){
	println("What do you want to do with your chosen numbers?")
	var operation = readLine.toLowerCase
	//operations(operation)
	operation match{
	case "add" => operations(Add) 
	case "subtract" => operations(Subtract)
	case "divide" => operations(Division)
	case "multiply" => operations(Multiplication)
	}
	println("Finish calculations? (y/n)")
	var endop = readLine.toLowerCase
	if (endop == "y"){
		end = 1
	}
}
println("DONE")